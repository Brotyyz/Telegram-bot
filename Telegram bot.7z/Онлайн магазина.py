from class_item import *
from Keyboard_for_shop import *

from aiogram.dispatcher.filters import Text
from aiogram import Bot, executor, Dispatcher, types
from dotenv import load_dotenv

import logging

load_dotenv()
logging.basicConfig(level=logging.DEBUG)
logging.getLogger('aiogram').setLevel(logging.INFO)

BOT_TOKEN = os.getenv('TOKEN')
bot = Bot(token=BOT_TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot)

TEXT_MENU = '''
    <b>Добро пожаловать в Онлайн магазин "Техник shop"!</b>
    <u>У нас огромный выбор техники!🖥 Низкие цены!💵</u>
    Доставка осуществляется в любую точку РФ.\n
    <i>Ждем ваши покупки!🔥🔥🔥</i>
    '''


@dp.message_handler(commands=['start'])
async def start_cmd(message: types.Message):
    await message.answer(TEXT_MENU, reply_markup=start_kb)


@dp.callback_query_handler(Text(equals='otzv_bt'))
async def otzv_list(call: types.CallbackQuery):
    await call.message.answer('С отзывами можете ознамится в группе в ВК')


@dp.callback_query_handler(Text(equals='info_bt'))
async def info_text(call: types.CallbackQuery):
    await call.message.answer('Интернет магазин Техник shop: широкий ассорти'
                              'мент электроники, цифровой и бытовой техники с '
                              'доставкой на дом и самовывозом...\n'
                              'У нас сейчас скидки! Успей купить свою мечту!')


@dp.callback_query_handler(Text(equals='kateg_bt'))
async def kateg_list(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите категорию товаров',
                              reply_markup=kateg_kb)


@dp.callback_query_handler(Text(equals='menu_bt'))
async def menu_cmd(call: types.CallbackQuery):
    await call.message.answer(TEXT_MENU, reply_markup=start_kb)
    await call.message.delete()


@dp.callback_query_handler(Text(equals='phone_bt'))
async def phone_menu(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите нужный вам товар',
                              reply_markup=phone_menu_kb)


@dp.callback_query_handler(Text(equals='notebook_bt'))
async def phone_menu(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите нужный вам товар',
                              reply_markup=notebook_menu_kb)


@dp.callback_query_handler(Text(equals='kitchen_bt'))
async def phone_menu(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите нужный вам товар (1 страница)',
                              reply_markup=kitchen_menu_kb)


@dp.callback_query_handler(Text(equals='sam_M22'))
async def p1(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **sam_M22.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='xia_9A'))
async def p2(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **xia_9A.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='xia_10S'))
async def p3(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **xia_10S.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='real_C25s'))
async def p4(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **real_C25s.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='real_8i'))
async def p5(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **real_8i.generate_invoice(),
                           payload='123456')  # Кнопки на телефоны


@dp.callback_query_handler(Text(equals='ASUS_B1'))
async def n1(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **ASUS_B1.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Acer_7'))
async def n2(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Acer_7.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='HP_Game'))
async def n3(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **HP_Game.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='ASUS_13'))
async def n4(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **ASUS_13.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Apple_Air'))
async def n5(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Apple_Air.generate_invoice(),
                           payload='123456')  # Кнопки на ноутбуки


@dp.callback_query_handler(Text(equals='StarWind'))
async def k1(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **StarWind.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Bosch'))
async def k2(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Bosch.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Redmond'))
async def k3(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Redmond.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Polaris_PMC'))
async def k4(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Polaris_PMC.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='DeLonghi_ECAM22'))
async def k5(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **DeLonghi_ECAM22.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='DeLonghi_ECAM23'))
async def k6(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **DeLonghi_ECAM23.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='Bosch_BFL554MW0'))
async def k7(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **Bosch_BFL554MW0.generate_invoice(),
                           payload='123456')


@dp.callback_query_handler(Text(equals='MAUNFELD_MBMO'))
async def k8(call: types.CallbackQuery):
    await bot.send_invoice(call.message.chat.id,
                           **MAUNFELD_MBMO.generate_invoice(),
                           payload='123456')  # Кнопки кух.оборудования


@dp.callback_query_handler(Text(equals='next_str'))
async def next_str(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите нужный вам товар (2 страница)',
                              reply_markup=kitchen_menu_kb2)


@dp.callback_query_handler(Text(equals='back_str'))
async def next_str(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите нужный вам товар (1 страница)',
                              reply_markup=kitchen_menu_kb)


@dp.callback_query_handler(Text(equals='go_back'))
async def back(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer('Выберите категорию товаров',
                              reply_markup=kateg_kb)


@dp.pre_checkout_query_handler()
async def process_pre_checkout_query(query: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query_id=query.id,
                                        ok=True)
    await bot.send_message(chat_id=query.from_user.id,
                           text='Спасибо за покупку!')


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
