from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

start_kb = InlineKeyboardMarkup()
kateg_bt = InlineKeyboardButton(text='Выбрать категорию',
                                callback_data='kateg_bt')
otzv_bt = InlineKeyboardButton(text='Отзывы', callback_data='otzv_bt')
info_bt = InlineKeyboardButton(text='О нас!', callback_data='info_bt')
start_kb.row(kateg_bt), start_kb.add(info_bt, otzv_bt)


kateg_kb = InlineKeyboardMarkup()
phone_bt = InlineKeyboardButton(text='Телефоны', callback_data='phone_bt')
notebook_bt = InlineKeyboardButton(text='Ноутбуки',
                                   callback_data='notebook_bt')
kitchen_bt = InlineKeyboardButton(text='Оборудование для кухни',
                                  callback_data='kitchen_bt')
menu_bt = InlineKeyboardButton(text='В меню', callback_data='menu_bt')
kateg_kb.add(phone_bt, notebook_bt), kateg_kb.row(kitchen_bt)
kateg_kb.add(menu_bt)

phone_menu_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text='Samsung Galaxy M22',
                              callback_data='sam_M22')],
        [InlineKeyboardButton(text='Xiaomi Redmi 9A',
                              callback_data='xia_9A')],
        [InlineKeyboardButton(text='Xiaomi Redmi Note 10S',
                              callback_data='xia_10S')],
        [InlineKeyboardButton(text='REALME C25s',
                              callback_data='real_C25s')],
        [InlineKeyboardButton(text='REALME 8i',
                              callback_data='real_8i')],
        [InlineKeyboardButton(text='Назад', callback_data='go_back')]
    ]
)

notebook_menu_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text='ASUS ExpertBook B1',
                              callback_data='ASUS_B1')],
        [InlineKeyboardButton(text='Acer Aspire 7',
                              callback_data='Acer_7')],
        [InlineKeyboardButton(text='HP Pavilion Gaming',
                              callback_data='HP_Game')],
        [InlineKeyboardButton(text='ASUS ZenBook 13',
                              callback_data='ASUS_13')],
        [InlineKeyboardButton(text='Apple MacBook Air',
                              callback_data='Apple_Air')],
        [InlineKeyboardButton(text='Назад', callback_data='go_back')]
    ]
)

kitchen_menu_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text='Тостер StarWind ST7002',
                              callback_data='StarWind')],
        [InlineKeyboardButton(text='Тостер Bosch TAT8611',
                              callback_data='Bosch')],
        [InlineKeyboardButton(text='Мультиварка Redmond RMC-M96',
                              callback_data='Redmond')],
        [InlineKeyboardButton(text='Мультиварка Polaris PMC 0366AD',
                              callback_data='Polaris_PMC')],
        [InlineKeyboardButton(text='Следующая страница',
                              callback_data='next_str')],
        [InlineKeyboardButton(text='Назад', callback_data='go_back')]
    ]
)

kitchen_menu_kb2 = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text='Кофемашина DeLonghi Magnifica ECAM22',
                              callback_data='DeLonghi_ECAM22')],
        [InlineKeyboardButton(text='Кофемашина DeLonghi Magnifica ECAM23',
                              callback_data='DeLonghi_ECAM23')],
        [InlineKeyboardButton(text='Микроволновая печь Bosch BFL554MW0',
                              callback_data='Bosch_BFL554MW0')],
        [InlineKeyboardButton(text='Микроволновая печь MAUNFELD MBMO.20',
                              callback_data='MAUNFELD_MBMO')],
        [InlineKeyboardButton(text='Предыдущая страница',
                              callback_data='back_str')]
    ]
)
