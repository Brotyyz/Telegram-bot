import os
from dataclasses import dataclass
from typing import List

from aiogram.types import LabeledPrice
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Item:
    title: str
    description: str
    currency: str
    prices: List[LabeledPrice]
    photo_url: str
    photo_width: int = None
    photo_height: int = None
    provider_token: str = os.getenv('PROVIDER_TOKEN')

    def generate_invoice(self):
        return self.__dict__


sam_M22 = Item(
    title='Samsung Galaxy M22',
    description='Операционная система - Android 11\n'
          'Дисплей - 6.4", Super AMOLED\n'
          'Разрешение дисплея - 1600x720\n'
          'Процессор - Mediatek Helio G80, 2000МГц, 8-ми ядерный\n'
          'Объем оперативной памяти - 4 ГБ\n'
          'Объем встроенной памяти - 128 ГБ\n'
          'Время работы в режиме разговора (max) - 38 ч',
    currency='RUB',
    prices=[LabeledPrice(label='Samsung Galaxy M22', amount=23_999_00)],
    photo_url='https://items.s1.citilink.ru/1613518_v01_b.jpg'
)

xia_9A = Item(
    title='Xiaomi Redmi 9A',
    description='Операционная система - Android 10\n'
          'Дисплей - 6.53", IPS\n'
          'Разрешение дисплея - 1600x720\n'
          'Процессор - MediaTek Helio G25, 2000МГц, 8-ми ядерный\n'
          'Объем оперативной памяти - 2 ГБ\n'
          'Объем встроенной памяти - 32 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='Xiaomi Redmi 9A', amount=8_990_00)],
    photo_url='https://items.s1.citilink.ru/1402120_v01_b.jpg'
)

xia_10S = Item(
    title='Xiaomi Redmi Note 10S',
    description='Операционная система - Android 11\n'
          'Дисплей - 6.43", AMOLED\n'
          'Разрешение дисплея - 2400x1080\n'
          'Процессор - Mediatek Helio G95, 2050МГц, 8-ми ядерный\n'
          'Объем оперативной памяти - 6 ГБ\n'
          'Объем встроенной памяти - 128 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='Xiaomi Redmi Note 10S', amount=23_990_00)],
    photo_url='https://items.s1.citilink.ru/1535842_v01_b.jpg'
)

real_C25s = Item(
    title='REALME C25s',
    description='Операционная система - Android 11\n'
          'Дисплей - 6.5", LCD\n'
          'Разрешение дисплея - 1600x720\n'
          'Процессор - Mediatek Helio G85, 2000МГц, 8-ми ядерный\n'
          'Объем оперативной памяти - 4 ГБ\n'
          'Объем встроенной памяти - 128 ГБ\n'
          'Время работы в режиме разговора (max) - 46 ч',
    currency='RUB',
    prices=[LabeledPrice(label='REALME C25s', amount=17_490_00)],
    photo_url='https://items.s1.citilink.ru/1594035_v01_b.jpg'
)

real_8i = Item(
    title='REALME 8i',
    description='Операционная система - Android 11\n'
          'Дисплей - 6.6", IPS\n'
          'Разрешение дисплея - 2412x1080\n'
          'Процессор - MediaTek G96, 2050МГц, 8-ми ядерный\n'
          'Объем оперативной памяти - 4 ГБ\n'
          'Объем встроенной памяти - 128 ГБ\n'
          'Время работы в режиме разговора (max) - 47 ч',
    currency='RUB',
    prices=[LabeledPrice(label='REALME 8i', amount=19_490_00)],
    photo_url='https://items.s1.citilink.ru/1613042_v01_b.jpg'
)

# ----------------------------------------------------------------------------

ASUS_B1 = Item(
    title='ASUS ExpertBook B1',
    description='🔥🔥🔥Основная информация🔥🔥🔥\n\n'
                'Тип экрана - IPS\n'
                'Максимальная частота обновления экрана - 60 Гц\n'
                'Модель процессора - Intel Core i5-1135G7\n'
                'Объем оперативной памяти - 8 ГБ\n'
                'Общий объем твердотельных накопителей (SSD) - 256 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='ASUS ExpertBook B1', amount=74_999_00)],
    photo_url='https://dlcdnwebimgs.asus.com/gain/89e029'
              '72-2ebb-49d3-9015-cd48a581efe1/'
)

Acer_7 = Item(
    title='Acer Aspire 7',
    description='🔥🔥🔥Основная информация🔥🔥🔥\n\n'
                'Тип экрана - IPS\n'
                'Максимальная частота обновления экрана - 60 Гц\n'
                'Модель процессора - Intel Core i5-10300H\n'
                'Объем оперативной памяти - 8 ГБ\n'
                'Общий объем твердотельных накопителей (SSD) - 512 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='Acer Aspire 7', amount=71_999_00)],
    photo_url='https://static.acer.com/up/Resource/Acer/Laptops/Aspire_7/imag'
              'es/20201005/Aspire-7-A715-75G-41G-FP-Black-modelmain.png'
)

HP_Game = Item(
    title='HP Pavilion Gaming',
    description='🔥🔥🔥Основная информация🔥🔥🔥\n\n'
                'Тип экрана - IPS\n'
                'Максимальная частота обновления экрана - 144 Гц\n'
                'Модель процессора - Intel Core i5-11300H\n'
                'Объем оперативной памяти - 8 ГБ\n'
                'Общий объем твердотельных накопителей (SSD) - 512 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='HP Pavilion Gaming', amount=84_999_00)],
    photo_url='https://ssl-product-images.www8-hp.com/dig'
              'medialib/prodimg/lowres/c06363439.png'
)

ASUS_13 = Item(
    title='ASUS ZenBook 13',
    description='🔥🔥🔥Основная информация🔥🔥🔥\n\n'
                'Тип экрана - OLED\n'
                'Максимальная частота обновления экрана - 60 Гц\n'
                'Модель процессора - Intel Core i7-1165G7\n'
                'Объем оперативной памяти - 8 ГБ\n'
                'Общий объем твердотельных накопителей (SSD) - 512 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='ASUS ZenBook 13', amount=89_999_00)],
    photo_url='https://dlcdnwebimgs.asus.com/gain/73'
              '7cedc0-11bd-480a-95a5-b387bcf234ca/w800'
)

Apple_Air = Item(
    title='Apple MacBook Air',
    description='🔥🔥🔥Основная информация🔥🔥🔥\n\n'
                'Тип экрана - IPS\n'
                'Максимальная частота обновления экрана - 60 Гц\n'
                'Модель процессора - Apple M1\n'
                'Объем оперативной памяти - 16 ГБ\n'
                'Общий объем твердотельных накопителей (SSD) - 512 ГБ',
    currency='RUB',
    prices=[LabeledPrice(label='Apple MacBook Air', amount=139_199_00)],
    photo_url='https://img.mvideo.ru/Big/30054305bb.jpg'
)

# ----------------------------------------------------------------------------

StarWind = Item(
    title='Тостер StarWind ST7002',
    description='Используя тостер STARWIND ST7002, вы сможете каждый день '
                'наслаждаться свежими и хрустящими тостами.\n\n'
                '🔥🔥🔥Основная информация на сайте🔥🔥🔥\n'
                'https://www.citilink.ru/product/toster-starwind-'
                'st7002-chernyi-1211564/',
    currency='RUB',
    prices=[LabeledPrice(label='Тостер StarWind ST7002', amount=1_290_00)],
    photo_url='https://items.s1.citilink.ru/1211564_v01_b.jpg'
)

Bosch = Item(
    title='Тостер Bosch TAT8611',
    description='Лучшим началом продуктивного дня является питательный и '
                'сытный завтрак. Приготовить тосты для себя и членов семьи '
                'вам поможет тостер BOSCH TAT8611.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/toster-bosch-'
                'tat8611-belyi-599628/',
    currency='RUB',
    prices=[LabeledPrice(label='Тостер Bosch TAT8611', amount=7_830_00)],
    photo_url='https://items.s1.citilink.ru/599628_v01_b.jpg'
)

Redmond = Item(
    title='Мультиварка Redmond RMC-M96',
    description='Приготовить вкусный обед, ужин или завтрак можно не только '
                'на традиционной плите, затрачивая массу времени.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/multivarka-redmond-rmc-'
                'm96-serebristyi-1387599/',
    currency='RUB',
    prices=[LabeledPrice(label='Мультиварка Redmond RMC-M96',
                         amount=8_860_00)],
    photo_url='https://items.s1.citilink.ru/1387599_v01_b.jpg'
)

Polaris_PMC = Item(
    title='Мультиварка Polaris PMC 0366AD',
    description='Мультиварка POLARIS PMC 0553AD поможет вам свести к минимуму '
                'хлопоты на кухне и при этом разнообразить свой рацион.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/multivarka-polaris-pmc-0366ad'
                '-550vt-chernyi-1178668/',
    currency='RUB',
    prices=[LabeledPrice(label='Мультиварка Polaris PMC 0366AD',
                         amount=5_699_00)],
    photo_url='https://items.s1.citilink.ru/1178668_v01_b.jpg'
)

DeLonghi_ECAM22 = Item(
    title='Кофемашина DeLonghi Magnifica ECAM22',
    description='Кофемашина DELONGHI Magnifica ECAM22.110B отличается '
                'многофункциональностью при простоте в использовании.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/kofemashina-delonghi-'
                'magnifica-ecam22-110b-chernyi-608775/',
    currency='RUB',
    prices=[LabeledPrice(label='Кофемашина DeLonghi Magnifica ECAM22',
                         amount=30_990_00)],
    photo_url='https://items.s1.citilink.ru/608775_v01_b.jpg'
)

DeLonghi_ECAM23 = Item(
    title='Кофемашина DeLonghi Magnifica ECAM23',
    description='Кофемашина DELONGHI Magnifica ECAM23.460B мощностью 1350 Вт '
                'и давлением помпы 15 Бар способна раскрыть уникальный '
                'аромат изысканного кофе.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/kofemashina-delonghi-'
                'magnifica-ecam23-460b-chernyi-482962/',
    currency='RUB',
    prices=[LabeledPrice(label='Кофемашина DeLonghi Magnifica ECAM23',
                         amount=53_990_00)],
    photo_url='https://items.s1.citilink.ru/482962_v01_b.jpg'
)

Bosch_BFL554MW0 = Item(
    title='Микроволновая печь Bosch BFL554MW0',
    description='Встраиваемая микроволновая печь Bosch BFL554MW0 – '
                'современный агрегат мощностью в 900 Вт. '
                'Объем камеры составляет 25 л.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/mikrovolnovaya-pech-'
                'bosch-bfl554mw0-25l-900vt-belyi-vstraivaemaya-1074870/',
    currency='RUB',
    prices=[LabeledPrice(label='Микроволновая печь Bosch BFL554MW0',
                         amount=48_990_00)],
    photo_url='https://items.s1.citilink.ru/1074870_v01_b.jpg'
)

MAUNFELD_MBMO = Item(
    title='Микроволновая печь MAUNFELD MBMO.20',
    description='Печь Maunfeld MBMO.20.2PGB сочетает стильное исполнение в '
                'глубоком черном цвете и весь необходимый набор функций. '
                'Она идеально подойдет для кухни в современном стиле и '
                'быстро приготовит ваши любимые блюда.\n\n'
                '🔥Основная информация на сайте🔥\n'
                'https://www.citilink.ru/product/mikrovolnovaya-pech-'
                'maunfeld-mbmo-20-2pgb-20l-1250vt-chernyi-vstraivae-1118075/',
    currency='RUB',
    prices=[LabeledPrice(label='Микроволновая печь MAUNFELD MBMO.20',
                         amount=22_990_00)],
    photo_url='https://items.s1.citilink.ru/1118075_v01_b.jpg'
)
